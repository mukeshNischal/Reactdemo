import React from "react";
import Header from "./component/Header"
import Footer from "./component/Footer"
import About from "./component/About";
import Home from "./component/Home"
import "./App.css";
import { BrowserRouter, Route, Link , Routes} from 'react-router-dom';
import Register from "./component/Register";
import Login from "./component/Login";

function App() {
  return (
    <div>
     
      <BrowserRouter>
      <Header />
       <Routes>
         <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          </Routes>
          <Footer/>
      </BrowserRouter>
    
    </div>
  )
}

export default App;
