import {useState} from "react"

const Register=()=>{

    const [userDetails, setUserDetails] = useState({
        firstname:"",
        lastname:"",
        mobile:"",
        email:"",
        password:""
    })
    const [formerror, setformError]= useState({
        firstnameError:"",
        lastnameError:"",
        mobileError:"",
        emailError:"",
        passwordError:""
    })

    const handleChange=(e)=>{
        setUserDetails({...userDetails, [e.target.name]:e.target.value})
        console.log(userDetails)
    }

    const handleSubmit=(e)=>{
        e.preventDefault()
            const {firstname, lastname,mobile,email,password}= userDetails // Destructure 

            const name_regex = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
            const email_regex = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
            const number_regex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
            const password_regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/;


            if(firstname === ""){
                setformError({firstnameError:"Please fill the firstname"})
                return false
            }
            else if (!name_regex.test(firstname)){
                setformError({firstnameError:"Please fill the valid firstname"})
                return false
            }
            else{
                setformError({firstnameError:""})
            }
    
            fetch('http://localhost:5000/register',{
                method:"post",
                body: JSON.stringify({firstname, lastname,mobile,email,password}),
                Headers:{"Content-type":"application/json; charset= UTF-8"}
                
            })
            .then(res=> res.json())
            .then(json=> console.log(json))
            .catch(()=>console.log("API Error "))
    }

    return (
        <div>
            <h1>Register</h1>

            <div>
                <form className="register-form">
                    <div className="form-group">
                        <label>Firstname</label>
                        <input type="text" className="form-control" placeholder="firstname" value={userDetails.firstname} name="firstname" onChange={handleChange} />
                        <span className="error">{formerror.firstnameError}</span>
                    </div>
                    <div className="form-group">
                        <label>Lastname</label>
                        <input type="text" className="form-control" placeholder="lastname" value={userDetails.lastname} name="lastname" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Email</label>
                        <input type="email" className="form-control" placeholder="email" value={userDetails.email} name="email" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Mobile No</label>
                        <input type="number" className="form-control" placeholder="Mobile" value={userDetails.mobile} name="mobile" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input type="password" className="form-control" placeholder="Password" value={userDetails.password} name="password" onChange={handleChange} />
                    </div>
                    <br/>
                    <button className="btn btn-primary" onClick={handleSubmit}>Register</button>
                </form>
            </div>
        </div>
    )
}

export default Register