import { useState } from "react"

const Login=()=>{
    const [loginDetails, setLoginDetails]= useState({
        email:"",
        password:"",
    })
    const submitHandle=(e)=>{
        setLoginDetails({...loginDetails, [e.target.name]:e.target.value})
        console.log(loginDetails);
    }
    return(
            <>
                <h1>Login</h1>
                <div>
                    <form>
                        <div className="form-group">
                            <input type="email" placeholder="Email" value={loginDetails.email} name="email" onChange={submitHandle} />                          
                        </div>

                        <div className="form-group">                          
                            <input type="password" placeholder="Password" value={loginDetails.password} name="password" onChange={submitHandle} />
                        </div>
                         
                        <button className="btn btn-success">Login</button>
                    </form>
                </div>
            </>
    )
}

export default Login