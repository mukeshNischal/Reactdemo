

const mongoose=require('mongoose')
const {Schema} = mongoose;

////// Design schema
const dataSchema=new Schema({
    firstname:String,
    lastname:String,
    mobile:Number,
    email:String,
    password:String,
    date : {type:Date, default: Date.now}
})

////// Create a Model
const Register = mongoose.model('newbatch', dataSchema);

module.exports= Register
