const { log } = require('console')
const express = require('express')
let http = require('http')
const cors = require('cors')
let app = express()

// connection file
require('./db/conn')

//model register connection
const Regis = require('./model/register')


// this is mandatory to use and  receive the body data in json format
app.use(express.json());
app.use(cors()); //this cors() need to me called

app.get('/', function (req, res) {
    res.send('Hello mukesh ')
})

app.post('/register', async(req,res)=>{
const { firstname,lastname,mobile,email,password} = req.body
     const register =  await Regis({firstname,lastname,mobile,email,password})
    const data = await register.save()
    res.send(data)
})

app.get('/fetch', async(req,res)=>{
  let data=  await  Regis.find()
  res.send(data);
})

app.get('/fetch/:id', async(req,res)=>{
  let data = await Regis.findById({_id: req.params.id})
  res.send(data)
})

app.delete('/fetch/:id', async(req,res)=>{
     let data=  await Regis.deleteOne({_id: req.params.id})
      res.send('delete successfully')
})

app.put('/fetch/:id', async(req,res)=>{
  let data=  await Regis.updateOne({_id: req.params.id}, {$set:req.body})
   res.send(data)
})

app.post('/login', async(req,res)=>{
    const {email, password}= req.body
})

app.listen(5000, ()=>console.log("app is running on port no 5000"))